const Home = () => {
  return (
    <div className="welcome-container">
      <h1 className="welcome-title">Welcome to IKs capstone!</h1>
    </div>
  );
};

export default Home;
